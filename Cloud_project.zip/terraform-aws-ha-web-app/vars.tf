variable "region" {
  default = "us-west-2"
}

variable "prefix_name" {
  default = "jeswanth"
}

variable "bucket_name" {
  default = "jeswanth-bucket"
}

variable "db_password" {
  default = "dbpassword"
}